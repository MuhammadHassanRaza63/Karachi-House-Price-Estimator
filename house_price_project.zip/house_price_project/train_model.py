import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

df = pd.read_csv(r"D:\Karachi_HPP project\house_price_project\karachidataset\Cleaned_Data.csv")
df.dropna(inplace=True)

# Step 1: Make Location_Grouped from Address
def simplify_location(address):
    if 'Bahria Town' in address:
        return 'Bahria Town'
    elif 'Scheme 33' in address:
        return 'Scheme 33'
    elif 'Gulistan-e-Jauhar' in address:
        return 'Gulistan-e-Jauhar'
    elif 'Askari 5' in address:
        return 'Askari 5'
    elif 'North Karachi' in address:
        return 'North Karachi'
    else:
        return 'Other'

df['Location_Grouped'] = df['Address'].apply(simplify_location)

# Step 2: Filter selected locations
selected_locations = ['Scheme 33', 'Bahria Town', 'Gulistan-e-Jauhar', 'Askari 5', 'North Karachi']
df = df[df['Location_Grouped'].isin(selected_locations)]

# Step 3: One-hot encode location
df = pd.get_dummies(df, columns=['Location_Grouped'], drop_first=True)

# Step 4: Prepare features and target
X = df.drop(['Price', 'Address', 'Unnamed: 0'], axis=1)
y = df['Price']

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Step 5: Save model and columns
joblib.dump(model, 'house_price_model.pkl')
joblib.dump(X.columns.tolist(), 'model_columns.pkl')
