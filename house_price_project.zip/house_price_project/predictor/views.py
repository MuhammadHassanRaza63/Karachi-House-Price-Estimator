from django.shortcuts import render
import joblib
import numpy as np
import pandas as pd

model = joblib.load('house_price_model.pkl')
model_columns = joblib.load('model_columns.pkl')

def calculate_accuracy():
    df = pd.read_csv(r"D:\Karachi_HPP project\house_price_project\karachidataset\Cleaned_Data.csv")
    df.dropna(inplace=True)

    def simplify_location(address):
        if 'Bahria Town' in address:
            return 'Bahria Town'
        elif 'Scheme 33' in address:
            return 'Scheme 33'
        elif 'Gulistan-e-Jauhar' in address:
            return 'Gulistan-e-Jauhar'
        elif 'Askari 5' in address:
            return 'Askari 5'
        elif 'North Karachi' in address:
            return 'North Karachi'
        else:
            return 'Other'

    df['Location_Grouped'] = df['Address'].apply(simplify_location)
    selected_locations = ['Scheme 33', 'Bahria Town', 'Gulistan-e-Jauhar', 'Askari 5', 'North Karachi']
    df = df[df['Location_Grouped'].isin(selected_locations)]
    df = pd.get_dummies(df, columns=['Location_Grouped'], drop_first=True)

    X = df.drop(['Price', 'Address', 'Unnamed: 0'], axis=1)
    y = df['Price']
    return round(model.score(X, y) * 100, 2)

model_accuracy = calculate_accuracy()

def home(request):
    return render(request, 'predictor/home.html')

def predict_price(request):
    if request.method == 'POST':
        area = float(request.POST.get('area'))
        bedrooms = int(request.POST.get('bedrooms'))
        bathrooms = int(request.POST.get('bathrooms'))
        location = request.POST.get('location')

        input_data = {
            'AreaSqYards': area,
            'NoOfBedrooms': bedrooms,
            'NoOfBathrooms': bathrooms
        }

        for col in model_columns:
            if 'Location_Grouped' in col:
                input_data[col] = 1 if col.split('_')[-1] == location else 0

        x = np.array([input_data.get(col, 0) for col in model_columns]).reshape(1, -1)
        predicted_price = int(model.predict(x)[0])

        def format_price(price):
            if price >= 10000000:
                return f"{round(price/10000000, 1)} crore ({price:,} PKR)"
            elif price >= 100000:
                return f"{round(price/100000, 1)} lakh ({price:,} PKR)"
            else:
                return f"{price:,} PKR"

        formatted_price = format_price(predicted_price)

        return render(request, 'predictor/home.html', {
            'result': formatted_price,
            'accuracy': model_accuracy
        })

    return render(request, 'predictor/home.html')
